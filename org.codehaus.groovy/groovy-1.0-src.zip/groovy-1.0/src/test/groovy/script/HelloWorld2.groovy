
x = ['James', 'Bob', 'Brian']
x.each { println("hello " + it) }

