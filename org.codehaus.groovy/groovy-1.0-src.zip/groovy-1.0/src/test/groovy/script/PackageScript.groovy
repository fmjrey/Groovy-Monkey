package groovy.script

println("Hello world")
