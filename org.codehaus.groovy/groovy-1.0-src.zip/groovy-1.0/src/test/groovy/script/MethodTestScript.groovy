GString.methods.each { println it.name }
