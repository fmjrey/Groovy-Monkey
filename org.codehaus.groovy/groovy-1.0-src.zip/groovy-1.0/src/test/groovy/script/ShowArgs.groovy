
for (a in args) {
    println("Argument: " + a)
}

