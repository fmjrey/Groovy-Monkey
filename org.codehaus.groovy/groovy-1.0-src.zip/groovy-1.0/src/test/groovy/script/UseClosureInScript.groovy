a = 1
[1].each { 
    a = it 
}
