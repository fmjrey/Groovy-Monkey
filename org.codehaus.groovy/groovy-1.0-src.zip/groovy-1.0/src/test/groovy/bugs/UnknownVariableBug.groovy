/**
 * @version $Revision: 4530 $
 */
class UnknownVariableBug extends GroovyTestCase {
    void testBug() {
        def shell = new GroovyShell()
        shouldFail {
            shell.evaluate """
                def x = foo
            """
        }
        shell.evaluate """
            foo = 1
            def x = foo
        """
    }
}