/**
 * @author Morgan Hankins
 * @version $Revision: 2285 $
 */
class MorgansBug extends GroovyTestCase {

    void testBug() {
        def result = 4 + "x"
        assert result == "4x"
    }
}