/**
 * @version $Revision: 1924 $
 */
class FullyQualifiedClassBug extends GroovyTestCase {

    void testBug() {
        java.lang.System.err.println("Hello world")
    }
    
}