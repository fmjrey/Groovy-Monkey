/**
 * @author Guillaume Laforge 
 * @version $Revision: 1924 $
 */
class GuillaumesBug extends GroovyTestCase {
    
    void testBug() {
        if (true) 
            println("true")
    }
}