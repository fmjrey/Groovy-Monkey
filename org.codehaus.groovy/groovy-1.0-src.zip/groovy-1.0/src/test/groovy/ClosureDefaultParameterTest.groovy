/** 
 * @author <a href="mailto:jstrachan@protique.com">James Strachan</a>
 * @version $Revision: 2603 $
 */
class ClosureDefaultParameterTest extends GroovyTestCase {

    void testClosureWithDefaultParams() {

        def block = {a = 123, b = 456 -> println "value of a = $a and b = $b" }

        block = { Integer a = 123, String b = "abc" ->
                  println "value of a = $a and b = $b"; return "$a $b".toString() }

        assert block.call(456, "def") == "456 def"
        assert block.call() == "123 abc"
        assert block(456) == "456 abc"
        assert block(456, "def") == "456 def"
    }

}

