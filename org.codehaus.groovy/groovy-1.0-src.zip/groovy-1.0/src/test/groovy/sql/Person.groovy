package groovy.sql

class Person {

    def firstName
    def lastName
    def age
}
