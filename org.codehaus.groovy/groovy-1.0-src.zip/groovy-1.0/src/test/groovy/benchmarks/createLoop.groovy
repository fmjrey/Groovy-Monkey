c = {
  for (i in 1..it){
    x = new Object()
  }
}
c.call(30000)

