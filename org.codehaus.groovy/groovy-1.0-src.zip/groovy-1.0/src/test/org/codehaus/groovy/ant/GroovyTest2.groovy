
def foo = new GroovyTest2Class()
foo.doSomething()
