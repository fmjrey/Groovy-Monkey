
class GroovyTest3Class
{

	void doSomething()
	{
		org.codehaus.groovy.ant.GroovyTest.FLAG = "from groovytest3.GroovyTest3Class.doSomething()"
	}
}
