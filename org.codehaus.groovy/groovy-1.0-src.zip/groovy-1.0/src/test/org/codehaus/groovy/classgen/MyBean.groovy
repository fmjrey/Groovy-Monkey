package org.codehaus.groovy.classgen

class MyBean {

	def name = "James"
	def foo = 123
}
