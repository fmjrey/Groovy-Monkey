package org.codehaus.groovy.dummy;

import java.io.Reader;

/**
 * @author Robert Fuller
 * @version $Revision: 1924 $
 */
public interface FooHandler {
    public void handle(Reader reader);
}
