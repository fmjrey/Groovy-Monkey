/*
 * IntA.java --
 *
 *
 * Copyright (c) 1997 by Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * RCS: @(#) $Id: IntA.java,v 1.1 1999/05/10 04:09:05 dejong Exp $
 *
 */

package tests.invoke;

public interface IntA {
    public String getStringA();
}

