/*
 * NoEventBean --
 *
 *	A Bean that has no events. Used to test the java::bind command.
 *
 * Copyright (c) 1997 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 * RCS: @(#) $Id: NoEventBean.java,v 1.1 1999/05/10 04:08:59 dejong Exp $
 */

package tcl.lang;

import java.util.*;

public class NoEventBean {

public NoEventBean() {}


} // end TesterBean

