package utmj.threaded.example;
/**
 * A bounded Buffer allows to put objects into and take objects from.
 * If there is no more space a put blocks.
 * If the buffer is empty the take blocks.
 *
 * The class contains a concurrency bug which can be verified by test class
 * NonDeterministicBoundedBufferTest.
 * see methods take() and put() to remove the bug.
 */
public class BoundedBuffer {
	private final static int DEFAULT_CAPACITY = 4;
	Object[] buffer;
	int putAt, takeAt, occupied;

/**
 * Create a bounded buffer with default capacity;
 */
public BoundedBuffer() {
	this(DEFAULT_CAPACITY);
}


/**
 * Create a bounded buffer with capacity as size of buffer;
 */
public BoundedBuffer(int capacity) {
	buffer = new Object[capacity];
}


/**
 * Put an object at the begin of the buffer. Block if buffer is full;
 */
public synchronized void put(Object x) throws InterruptedException {
	while(occupied == buffer.length) {
		wait();
	}
	notify(); // Can result in concurrency problems
	//notifyAll();
	++ occupied;
	putAt %= buffer.length;
	buffer[putAt++] = x;
}


/**
 * Take an object from the end of the buffer. Block if buffer is empty
 */
public synchronized Object take() throws InterruptedException {
	while (occupied == 0) {
		wait();
	}
	notify(); // Can result in concurrency problems
	//notifyAll();
	--occupied;
	takeAt %= buffer.length;
	return buffer[takeAt++];
}
}