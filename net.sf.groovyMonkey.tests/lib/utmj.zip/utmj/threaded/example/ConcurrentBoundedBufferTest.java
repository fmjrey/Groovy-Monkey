package utmj.threaded.example;
import java.util.*;

import utmj.threaded.ConcurrentTestCase;

public class ConcurrentBoundedBufferTest extends ConcurrentTestCase {
	protected BoundedBuffer buffer;

public ConcurrentBoundedBufferTest(String name) {
	super(name);
}


protected void addPut5Threads(int numberOfThreads, String threadNamePrefix) {
	for (int i = 0; i < numberOfThreads; i++) {
		Runnable putRunnable = this.put5Runnable();
		this.addThread(threadNamePrefix + i, putRunnable);
	}
}


protected void addTake5Threads(int numberOfThreads, Vector takeBuffer, String threadNamePrefix) {
	for (int i = 0; i < numberOfThreads; i++) {
		Runnable takeRunnable = this.take5Runnable(takeBuffer);
		this.addThread(threadNamePrefix + i, takeRunnable);
	}
}


protected void assertOccurrences(int expected, Object element, Vector collection) {
	int actual = 0;
	Enumeration enum = collection.elements();
	while(enum.hasMoreElements()) {
		Object each = enum.nextElement();
		if (each.equals(element)) {
			actual++;
		}
	}
	assertEquals("Occurrences of " + element.toString(), expected, actual);
}


protected Runnable put5Runnable() {
	Runnable runnable = new Runnable() {
		public void run() {
			try {
				buffer.put("a");
				buffer.put("b");
				buffer.put("c");
				buffer.put("d");
				checkpoint("before put 5");
				buffer.put("e");
				checkpoint("after put 5");
			} catch (InterruptedException ignored) {}
		}
	};
	return runnable;
}


protected Runnable putRunnable(final int numberOfPuts) {
	Runnable runnable = new Runnable() {
		public void run() {
			for (int i = 0; i < numberOfPuts; i++) {
				try {
					buffer.put("a");
				} catch (InterruptedException ignored) {
				}
			}
		}
	};
	return runnable;
}


protected void setUp() {
	super.setUp();
}


protected Runnable take5Runnable(final Vector takeBuffer) {
	return this.takeRunnable(5, takeBuffer);
}


protected Runnable takeRunnable(final int numberOfTakes, final Vector takeBuffer) {
	Runnable runnable = new Runnable() {
		public void run() {
			for (int i = 1; i <= numberOfTakes; i++) {
				try {
					takeBuffer.addElement(buffer.take());
				} catch (InterruptedException ignored) {
					break; // To enable interruption on test tear down
				}
			}
		}
	};
	return runnable;
}
}