package utmj.threaded.example;
import java.util.Vector;

import junit.framework.*;
/**
 * Non-deterministic tests sometimes fail and sometimes don't.
 * Therefore the suite uses a RepeatedTest-Decorator.
 */
public class NonDeterministicBoundedBufferTest extends ConcurrentBoundedBufferTest {
public NonDeterministicBoundedBufferTest(String name) {
	super(name);
}


protected void setUp() {
	super.setUp();
	buffer = new BoundedBuffer(1); // The smaller the buffer, the more test failures
}


public static Test suite() {
	TestSuite suite = new TestSuite(NonDeterministicBoundedBufferTest.class);
	// Running the suite 20x usually results in 3-10 failures
	return new junit.extensions.RepeatedTest(suite, 20);
}


public void testTenPutThreadsVersusOneTakeThread() throws Exception {
	this.addPut5Threads(10, "putThread");
	Vector takeBuffer = new Vector();
	Runnable takeRunnable = this.takeRunnable(50, takeBuffer);
	this.addThread("takeThread", takeRunnable);
	this.startAndJoinThreads(500);
	assertEquals("Buffer is empty", 0, buffer.occupied);
	assertEquals("Buffer size", 50, takeBuffer.size());
	assertEquals("First must be a", "a", takeBuffer.firstElement());
	assertEquals("Last must be e", "e", takeBuffer.elementAt(49));
	assertOccurrences(10, "a", takeBuffer);
	assertOccurrences(10, "b", takeBuffer);
	assertOccurrences(10, "c", takeBuffer);
	assertOccurrences(10, "d", takeBuffer);
	assertOccurrences(10, "e", takeBuffer);
}


public void testTenTakeThreadsVersusOnePutThread() throws Exception {
	Vector takeBuffer = new Vector();
	this.addTake5Threads(5, takeBuffer, "takeThreadOne");
	Runnable put50Runnable = putRunnable(50);
	this.addThread("putThread", put50Runnable);
	this.addTake5Threads(5, takeBuffer, "takeThreadTwo");
	this.startAndJoinThreads(500);
	assertEquals("Buffer is empty", 0, buffer.occupied);
	assertEquals("Buffer size", 50, takeBuffer.size());
	assertOccurrences(50, "a", takeBuffer);
}


/**
 * Attempt to provoke the concurrency bug with the smallest number of threads.
 * But I never got it to fail. Not even in 10000 runs.
 */
public void testTwoPutThreadsVersusOneTakeThread() throws Exception {
	final Vector takeBuffer = new Vector();
	Runnable putRunnable = new Runnable() {
		public void run() {
			try {
				waitForCheckpoint("go");
				buffer.put("a");
			} catch (InterruptedException ignored) {}
		}
	};
	Runnable takeRunnable = new Runnable() {
		public void run() {
			try {
				waitForCheckpoint("go");
				takeBuffer.addElement(buffer.take());
			} catch (InterruptedException ignored) {}
		}
	};
	this.addThread("put1", putRunnable);
	this.addThread("put2", putRunnable);
	this.addThread("take", takeRunnable);
	this.startThreads();
	checkpoint("go");
	this.joinAllThreads(1000);
	assertTrue("Deadlock", ! this.deadlockDetected());
	assertEquals("One taken", 1, takeBuffer.size());
	assertEquals("'a' taken", "a", takeBuffer.firstElement());
	assertEquals("Buffer full", 1, buffer.occupied);
}
}