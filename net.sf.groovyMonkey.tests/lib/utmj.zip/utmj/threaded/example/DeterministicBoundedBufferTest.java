package utmj.threaded.example;
import java.util.Vector;

/**
 * Those tests always succeed.
 */
public class DeterministicBoundedBufferTest extends ConcurrentBoundedBufferTest {
public DeterministicBoundedBufferTest(String name) {
	super(name);
}


protected void setUp() {
	super.setUp();
	buffer = new BoundedBuffer();
}


public void testFivePuts() {
	Runnable runnable = this.put5Runnable();
	this.addThread("putThread", runnable);
	this.startAndJoinThreads(200);
	assertEquals("Buffer full", 4, buffer.occupied);
	assertTrue(this.checkpointReached("before put 5"));
	assertTrue(!this.checkpointReached("after put 5"));
	assertTrue(this.deadlockDetected());
}


public void testFivePutsAndTakes() throws Exception {
	Runnable put5Runnable = put5Runnable();
	Vector takeBuffer = new Vector();
	Runnable take5Runnable = take5Runnable(takeBuffer);
	this.addThread("putThread", put5Runnable);
	this.addThread("takeThread", take5Runnable);
	this.startAndJoinThreads(1000);
	assertTrue(!this.deadlockDetected());
	assertEquals("Buffer is empty", 0, buffer.occupied);
	assertEquals("a", takeBuffer.elementAt(0));
	assertEquals("b", takeBuffer.elementAt(1));
	assertEquals("c", takeBuffer.elementAt(2));
	assertEquals("d", takeBuffer.elementAt(3));
	assertEquals("e", takeBuffer.elementAt(4));
}


public void testFivePutsSingleTake() throws Exception {
	Runnable put5Runnable = put5Runnable();
	this.addThread("putThread", put5Runnable);
	this.startThreads();
	this.waitForCheckpoint("before put 5");
	assertTrue("Put thread should be blocked", !this.checkpointReached("after put 5"));
	assertEquals("buffer should be full", 4, buffer.occupied);
	assertEquals("a", buffer.take()); //should awake waiting putThread
	this.waitUntilFinished("putThread");
	assertEquals("buffer should again be full", 4, buffer.occupied);
	assertTrue(this.hasThreadFinished("putThread"));
}


public void testFourThreads() throws Exception {
	Runnable put5Runnable1 = put5Runnable();
	Runnable put5Runnable2 = put5Runnable();
	Vector takeBuffer = new Vector();
	Runnable take5Runnable1 = take5Runnable(takeBuffer);
	Runnable take5Runnable2 = take5Runnable(takeBuffer);
	this.addThread("putThread1", put5Runnable1);
	this.addThread("putThread2", put5Runnable2);
	this.addThread("takeThread1", take5Runnable1);
	this.addThread("takeThread2", take5Runnable2);
	this.startAndJoinThreads(1000);
	assertTrue(!this.deadlockDetected());
	assertEquals("Buffer is empty", 0, buffer.occupied);
	assertEquals(10, takeBuffer.size());
	assertEquals("First must be a", "a", takeBuffer.firstElement());
	assertEquals("Last must be e", "e", takeBuffer.elementAt(9));
	assertTrue(takeBuffer.contains("a"));
	assertTrue(takeBuffer.contains("b"));
	assertTrue(takeBuffer.contains("c"));
	assertTrue(takeBuffer.contains("d"));
	assertTrue(takeBuffer.contains("e"));
}


public void testSingleTake() {
	Runnable runnable = new Runnable() {
		public void run() {
			try {
				checkpoint("before take");
				buffer.take(); //should block
				checkpoint("after take");
			} catch (InterruptedException ignored) {}
		}
	};
	this.addThread("takeThread", runnable);
	this.startAndJoinThreads(200);
	assertTrue(this.checkpointReached("before take"));
	assertTrue(!this.checkpointReached("after take"));
	assertTrue(this.deadlockDetected());
}


public void testTwentyThreads() throws Exception {
	Vector takeBuffer = new Vector();
	this.addPut5Threads(10, "putThread");
	this.addTake5Threads(10, takeBuffer, "takeThread");
	this.startAndJoinThreads(6000);
	assertEquals("Buffer is empty", 0, buffer.occupied);
	assertEquals(50, takeBuffer.size());
	assertEquals("First must be a", "a", takeBuffer.firstElement());
	assertEquals("Last must be e", "e", takeBuffer.elementAt(49));
	assertTrue(takeBuffer.contains("a"));
	assertTrue(takeBuffer.contains("b"));
	assertTrue(takeBuffer.contains("c"));
	assertTrue(takeBuffer.contains("d"));
	assertTrue(takeBuffer.contains("e"));
}
}