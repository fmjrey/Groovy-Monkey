package utmj.threaded.example;
public class NonConcurrentBoundedBufferTest extends junit.framework.TestCase {
	private BoundedBuffer buffer;

public NonConcurrentBoundedBufferTest(String name) {
	super(name);
}


protected void setUp() {
	buffer = new BoundedBuffer();
}


public void testCreation() throws Exception {
	assertEquals("Default capacity", 4, buffer.buffer.length);
	assertEquals(0, buffer.putAt);
	assertEquals(0, buffer.takeAt);
	assertEquals(0, buffer.occupied);
}
		
public void testFourPuts() throws Exception {
	buffer.put("a");
	buffer.put("b");
	buffer.put("c");
	buffer.put("d");
	assertEquals(4, buffer.putAt);
	assertEquals(0, buffer.takeAt);
	assertEquals(4, buffer.occupied);
	assertEquals("a", buffer.buffer[0]);
	assertEquals("b", buffer.buffer[1]);
	assertEquals("c", buffer.buffer[2]);
	assertEquals("d", buffer.buffer[3]);
}
		
public void testFourTakes() throws Exception {
	buffer.buffer[0] = "a";
	buffer.buffer[1] = "b";
	buffer.buffer[2] = "c";
	buffer.buffer[3] = "d";
	buffer.occupied = 4;
	buffer.takeAt = 2;
	assertEquals("c", buffer.take());
	assertEquals("d", buffer.take());
	assertEquals("a", buffer.take());
	assertEquals("b", buffer.take());
	assertEquals(0, buffer.occupied);
	assertEquals(2, buffer.takeAt);
}
		
public void testSeveralPutTakes() throws Exception {
	buffer.put("a");
	buffer.put("b");
	buffer.put("c");
	buffer.put("d");
	Object taken = buffer.take();
	assertEquals("a", taken);
	taken = buffer.take();
	assertEquals("b", taken);
	taken = buffer.take();
	assertEquals("c", taken);
	taken = buffer.take();
	assertEquals("d", taken);
	buffer.put("e");
	taken = buffer.take();
	assertEquals("e", taken);
	assertEquals(1, buffer.putAt);
	assertEquals(1, buffer.takeAt);
	assertEquals(0, buffer.occupied);

}
		
public void testSinglePut() throws Exception {
	buffer.put("a");
	assertEquals(1, buffer.putAt);
	assertEquals(0, buffer.takeAt);
	assertEquals(1, buffer.occupied);
	assertEquals("a", buffer.buffer[0]);
}
		
public void testSinglePutTake() throws Exception {
	buffer.put("a");
	Object taken = buffer.take();
	assertEquals("a", taken);
	assertEquals(1, buffer.putAt);
	assertEquals(1, buffer.takeAt);
	assertEquals(0, buffer.occupied);
}
		}