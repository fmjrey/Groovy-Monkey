package utmj.threaded.example;
import junit.framework.*;

/**
 * All tests for utmj.threaded.example
 */
public class AllTests {
public static void main(String[] args) {
	junit.textui.TestRunner.run(suite());
}


public static Test suite() {
	TestSuite suite = new TestSuite("All utmj.threaded.example.* Tests");
	suite.addTestSuite(NonConcurrentBoundedBufferTest.class);
	suite.addTestSuite(DeterministicBoundedBufferTest.class);
	suite.addTest(NonDeterministicBoundedBufferTest.suite());
	return suite;
}
}