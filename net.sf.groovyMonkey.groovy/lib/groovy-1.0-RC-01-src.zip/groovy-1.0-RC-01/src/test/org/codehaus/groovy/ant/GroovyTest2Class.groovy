
class GroovyTest2Class
{

	void doSomething()
	{
		org.codehaus.groovy.ant.GroovyTest.FLAG = "from GroovyTest2Class.doSomething()"
	}
}
