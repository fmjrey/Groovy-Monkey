package org.codehaus.groovy.classgen

class Main {
    
    def main() {
        println("Hello World!")
    }
}
