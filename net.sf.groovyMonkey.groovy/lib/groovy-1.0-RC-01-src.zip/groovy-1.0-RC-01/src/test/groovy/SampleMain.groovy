class SampleMain {
    static void main(args) {
        for (arg in args) {
            println("Argument: " + arg)
        }
    }
}
