/** 
 * Tests Closures in Groovy
 * 
 * @author <a href="mailto:james@coredevelopers.net">James Strachan</a>
 * @version $Revision: 2018 $
 */
class ClosureAsParamTest extends GroovyTestCase {

    void testSimpleBlockCall() {
        assertClosure({owner-> println(owner) })
    }
  
    def assertClosure(Closure block) {
        assert block != null
        block.call("hello!")
    }
}
