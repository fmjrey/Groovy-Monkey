package groovy;

public interface DummyInterface {

    public void methodWithArrayParam(String[] args);
}
