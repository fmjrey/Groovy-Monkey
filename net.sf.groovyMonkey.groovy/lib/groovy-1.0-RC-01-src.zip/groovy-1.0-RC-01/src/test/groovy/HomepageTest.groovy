class HomepageTest extends GroovyTestCase {

	void testHomePage() {
	    
	}
}
