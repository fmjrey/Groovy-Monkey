/**
 * @version $Revision: 2284 $
 */
class CallingClosuresWithClosuresBug extends GroovyTestCase {

    void testBug() {
        def a = {1}
        // old workaround
        //def b = {a.call()}
        def b = {a()}
        
        def value = b()
        
        assert value == 1
    }
}