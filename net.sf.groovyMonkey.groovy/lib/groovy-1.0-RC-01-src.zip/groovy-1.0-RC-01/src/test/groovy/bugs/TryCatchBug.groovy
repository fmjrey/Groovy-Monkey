/**
 * @author John Wilson
 * @version $Revision: 1924 $
 */
class TryCatchBug extends GroovyTestCase {
    
    void testBug() {
        try {
            println("Hello")
        }
        finally {
            println("Finally")
        }
    }
}