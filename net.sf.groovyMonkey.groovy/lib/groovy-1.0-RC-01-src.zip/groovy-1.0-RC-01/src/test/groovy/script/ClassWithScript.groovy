class X {}
x = new X()
println(x)