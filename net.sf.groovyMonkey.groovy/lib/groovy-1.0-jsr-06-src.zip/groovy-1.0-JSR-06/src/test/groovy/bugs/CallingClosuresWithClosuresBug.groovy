/**
 * @version $Revision: 1.6 $
 */
class CallingClosuresWithClosuresBug extends GroovyTestCase {

    void testBug() {
        def a = {1}
        // old workaround
        //def b = {a.call()}
        def b = {a()}
        
        def value = b()
        
        assert value == 1
    }
}