/**
 * @version $Revision: 1.3 $
 */
class FullyQualifiedClassBug extends GroovyTestCase {

    void testBug() {
        java.lang.System.err.println("Hello world")
    }
    
}