/**
 * @version $Revision: 1.5 $
 */
class RodsBooleanBug extends GroovyTestCase {

    def item = "hi"
    
    void testBug() {
        assert isIt()
    }
    
    def isIt() {
        return item != null && item == "hi"
    }
    
}