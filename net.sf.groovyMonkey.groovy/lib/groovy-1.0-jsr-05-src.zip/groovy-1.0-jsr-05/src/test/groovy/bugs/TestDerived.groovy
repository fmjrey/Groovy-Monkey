/**
 * A base class for testing constructors
 * 
 * @version $Revision: 1.5 $
 */

 class TestDerived extends TestBase {

     TestDerived(String aFoo) {
         super(aFoo)
     }
     
     def doSomething() {
     	"TestDerived" + super.doSomething()
     }
 }