/**
 * @version $Revision: 1.4 $
 */
class UseClosureInClosureBug extends GroovyTestCase {
    
    void testBug() {
        def closure = { println it }
        
        def anotherClosure = { closure(it) }
        anotherClosure("Hello")
    }
}