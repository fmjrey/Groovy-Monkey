/** 
 * @author Robert Kuzelj
 * @version $Revision: 1.5 $
 */
class StaticClosurePropertyBug extends GroovyTestCase {

    static def out = {System.out.println(it)}
    
    void testCallStaticClosure() {
        callStaticClosure()
    }
    
    static def callStaticClosure() {
        out("TEST")
    }
}
