/**
 * @version $Revision: 1.2 $
 */
class FullyQualifiedVariableTypeBug extends GroovyTestCase {

    void testBug() {
        java.lang.String s = "hey"
        assert s.length() == 3
    }

}